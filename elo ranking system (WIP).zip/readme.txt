Elo ranking system,

Text based elo system with 8 man bracket functionality. 